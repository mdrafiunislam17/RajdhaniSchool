<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <li>
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
            <div class="sidebar-brand-icon rotate-n-15">

                <img src="<?php echo e(asset("storage/uploads/" . $settings["SETTING_SITE_LOGO"])); ?>" class="w-75" alt="">

            </div>
            <h6 class="sidebar-brand-text mx-3 mt-2 font-weight-bold" title=" sc-edu-bd.com"> sc-edu-bd.com</h6>
        </a>
    </li>


    <li class="nav-item ">
        <a class="nav-link" href="#">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

        <li class="nav-item <?php echo e(request()->routeIs("sliders.index") ||
            request()->routeIs("sliders.create") ||
            request()->routeIs("sliders.show") ||
            request()->routeIs("sliders.edit")
            ? "active" : ""); ?>">
            <a class="nav-link" href="<?php echo e(route("sliders.index")); ?>">
                <i class="fas fa-fw fa-tablet"></i>
                <span>Sliders</span>
            </a>
        </li>

    <li class="nav-item <?php echo e(request()->routeIs('setting.index') || request()->routeIs('setting.update') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('setting.index')); ?>">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
    </li>

  <li class="nav-item }}
        request()->routeIs('abouts.index') ||
        request()->routeIs('abouts.create') ||
        request()->routeIs('abouts.show') ||
        request()->routeIs('abouts.edit') ? 'active' : '' }}">
        <a class="nav-link" href="<?php echo e(route('abouts.index')); ?>">
            <i class="fas fa-fw fa-info-circle"></i>
            <span>About</span>
        </a>
    </li>

    






























































    

































  


  











































































































































</ul>
<?php /**PATH F:\project\School\resources\views/admin/layouts/aside.blade.php ENDPATH**/ ?>