<?php $__env->startSection("title", "Settings"); ?>
<?php $__env->startSection("content"); ?>
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Settings</h1>
            <a href="<?php echo e(route("setting.index")); ?>"
               class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-sync fa-sm text-white-50"></i> Settings</a>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <ul class="m-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->has("success")): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session("success")); ?>

            </div>
        <?php endif; ?>

        <?php if(session()->has("error")): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session("error")); ?>

            </div>
        <?php endif; ?>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <form action="<?php echo e(route("setting.update")); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    

                    
                    <div class="form-group row">
                        <label for="SETTING_SITE_LOGO"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Logo</label>
                        <div class="col-sm-6">
                            <img src="<?php echo e(asset("uploads/" . $settings["SETTING_SITE_LOGO"])); ?>"
                                 alt="<?php echo e($settings["SETTING_SITE_LOGO"]); ?>" width="150">
                            <input type="file" class="form-control" id="SETTING_SITE_LOGO" name="SETTING_SITE_LOGO">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="SETTING_SITE_FAVICON"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Favicon</label>
                        <div class="col-sm-6">
                            <img src="<?php echo e(asset("uploads/" . $settings["SETTING_SITE_FAVICON"])); ?>"
                                 alt="<?php echo e($settings["SETTING_SITE_FAVICON"]); ?>" width="150">
                            <input type="file" class="form-control" id="SETTING_SITE_FAVICON"
                                   name="SETTING_SITE_FAVICON">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="SETTING_PAGE_BANNER"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Page Banner</label>
                        <div class="col-sm-6">
                            <img src="<?php echo e(asset("uploads/" . $settings["SETTING_PAGE_BANNER"])); ?>"
                                 alt="<?php echo e($settings["SETTING_PAGE_BANNER"]); ?>" width="150">
                            <input type="file" class="form-control" id="SETTING_PAGE_BANNER"
                                   name="SETTING_PAGE_BANNER">
                        </div>
                    </div>

                    <hr>

                    <div class="form-group row">
                        <label for="SETTING_SOCIAL_FACEBOOK"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Facebook URL</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="SETTING_SOCIAL_FACEBOOK"
                                   value="<?php echo e($settings["SETTING_SOCIAL_FACEBOOK"]); ?>"
                                   name="SETTING_SOCIAL_FACEBOOK">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="SETTING_SOCIAL_YOUTUBE"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Youtube URL</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="SETTING_SOCIAL_YOUTUBE"
                                   value="<?php echo e($settings["SETTING_SOCIAL_YOUTUBE"]); ?>"
                                   name="SETTING_SOCIAL_YOUTUBE">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="SETTING_SOCIAL_INSTAGRAM"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Instagram URL</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="SETTING_SOCIAL_INSTAGRAM"
                                   value="<?php echo e($settings["SETTING_SOCIAL_INSTAGRAM"]); ?>"
                                   name="SETTING_SOCIAL_INSTAGRAM">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="SETTING_SOCIAL_LINKEDIN"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Linkedin URL</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="SETTING_SOCIAL_LINKEDIN"
                                   value="<?php echo e($settings["SETTING_SOCIAL_LINKEDIN"]); ?>"
                                   name="SETTING_SOCIAL_LINKEDIN">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="SETTING_SOCIAL_TWITTER"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Twitter URL</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="SETTING_SOCIAL_TWITTER"
                                   value="<?php echo e($settings["SETTING_SOCIAL_TWITTER"]); ?>"
                                   name="SETTING_SOCIAL_TWITTER">
                        </div>
                    </div>

                    <hr>

                    <div class="form-group row">
                        <label for="CONTACT_EMAIL"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Contact Email</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="CONTACT_EMAIL"
                                   value="<?php echo e($settings["CONTACT_EMAIL"]); ?>"
                                   name="CONTACT_EMAIL">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="CONTACT_PHONE"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Contact Phone</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="CONTACT_PHONE"
                                   value="<?php echo e($settings["CONTACT_PHONE"]); ?>"
                                   name="CONTACT_PHONE">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="CONTACT_ADDRESS"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Contact Address</label>
                        <div class="col-sm-6">
                            <textarea name="CONTACT_ADDRESS" id="CONTACT_ADDRESS" class="form-control"
                                      style="min-height: 200px"><?php echo e($settings["CONTACT_ADDRESS"]); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="CONTACT_GOOGLE_MAP"
                               class="col-sm-3 col-form-label text-right font-weight-bold">Contact Google Map</label>
                        <div class="col-sm-6">
                            <textarea name="CONTACT_GOOGLE_MAP" id="CONTACT_GOOGLE_MAP" class="form-control"
                                      style="min-height: 200px"><?php echo e($settings["CONTACT_GOOGLE_MAP"]); ?></textarea>
                        </div>
                    </div>

                    <hr>
                    

                    <div class="form-group row">
                        <div class="offset-3 col-sm-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.8.2/tinymce.min.js" referrerpolicy="origin"></script>

    <script>
        tinymce.init({
            selector: '#HOME_PAGE_CONTENT',  // Use textarea as the editor
            height: 500,           // Set the height of the editor
            plugins: 'advlist autolink lists link image charmap print preview anchor',
            toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | image link',
            menubar: false,
        });

        tinymce.init({
            selector: '#SETTING_ABOUT_US',  // Use textarea as the editor
            height: 500,           // Set the height of the editor
            plugins: 'advlist autolink lists link image charmap print preview anchor',
            toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | image link',
            menubar: false,
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\School\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>