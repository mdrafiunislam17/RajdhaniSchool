<!-- HEADER SECTION START -->
<header class="absolute z-[99] top-0 inset-x-[100px] xxl:inset-x-[30px] xl:inset-x-0 bg-white rounded-bl-[10px] rounded-br-[10px]">
    <!-- top header -->
































    <!-- bottom header -->
    <div class="px-[30px] xxl:px-[15px] lg:px-[20px] py-[28px] lg:py-[18px] flex justify-between to-be-fixed">
        <div class="logo xxs:max-w-[40%]">
            <a href="<?php echo e(route('front.index')); ?>">
                <img src="<?php echo e(asset("uploads/" . $settings["SETTING_SITE_LOGO"])); ?>" alt="logo" class="logo">
            </a></div>

        <div class="flex lg:items-center lg:gap-[60px] xxs:gap-[30px]">
            <div class="flex items-center gap-[100px] xl:gap-[30px] lg:gap-y-0">
                <!-- nav -->
                <div class="ed-header-nav-container">
                    <ul class="to-go-to-sidebar-in-mobile ed-header-nav flex lg:flex-col gap-x-[43px] xl:gap-x-[33px] font-kanit text-[17px]  font-normal" style="padding-right: 155px ;">
                        <li class="has-sub-menu relative">
                            <a role="button">Home</a>





                        </li>
                        <li><a href="#">About us</a></li>
                        <li class="has-sub-menu relative">
                            <a role="button">Courses</a>

                            <ul class="ed-header-submenu">
                                <li><a href="#">Courses Grid</a></li>
                                <li><a href="#">Courses Filter</a></li>
                                <li><a href="#">Course Details</a></li>
                            </ul>
                        </li>
                        <li class="has-sub-menu relative">
                            <a role="button">Pages</a>

                            <ul class="ed-header-submenu">
                                <li><a href="#">Teachers</a></li>
                                <li><a href="#">Events</a></li>
                                <li><a href="#">Gallery</a></li>
                                <li><a href="#">FAQ</a></li>


                            </ul>
                        </li>
                        <li class="has-sub-menu relative">
                            <a role="button">Blog</a>






                        </li>
                        <li><a href="#">Contact us</a></li>
                    </ul>
                </div>

                <!-- right actions -->
                <div class="flex items-center gap-x-[60px] xxs:gap-[30px]">

                    <a href="#" class="ed-btn to-go-to-sidebar-in-mobile lg:m-[20px]">apply now</a>
                </div>
            </div>

            <!-- mobile menu button -->
            <button type="button" class="ed-mobile-menu-open-btn hidden lg:inline-block text-edblue text-[18px]"><i class="fa-solid fa-bars"></i></button>
        </div>
    </div>
</header>
<!-- HEADER SECTION END -->
<?php /**PATH F:\project\School\resources\views/front/layouts/header.blade.php ENDPATH**/ ?>