<?php $__env->startSection("title", "About"); ?>
<?php $__env->startSection("content"); ?>
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Abouts</h1>
            <a href="<?php echo e(route("abouts.create")); ?>"
               class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                    class="fas fa-plus fa-sm text-white-50"></i> Create abouts</a>
        </div>

        <?php if(session()->has("success")): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session("success")); ?>

            </div>
        <?php endif; ?>

        <?php if(session()->has("error")): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <?php echo e(session("error")); ?>

            </div>
        <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable">
                        <thead>
                        <tr>
                            <th>#SL</th>
                            <th>Title</th>
                            <th>Image</th>

                            <th style="width: 100px">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($about->title); ?></td>
                                <td><img src="<?php echo e(asset("uploads/about/$about->image")); ?>" width="100" alt=""></td>


                                <td>


                                    <a href="<?php echo e(route("abouts.edit", $about->id)); ?>" class="btn btn-sm btn-warning"><i
                                            class="fa fa-edit"></i></a>
                                    <form action="<?php echo e(route('abouts.destroy', $about->id)); ?>" method="post" class="d-inline delete-form" data-id="<?php echo e($about->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-sm btn-danger delete-btn h-100" data-id="<?php echo e($about->id); ?>">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>




    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-danger">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel"><i class="fa fa-trash me-2"></i> Confirm Deletion</h5>
                    
                    
                </div>
                <div class="modal-body text-center">
                    <p class="fs-5">Are you sure you want to delete this About?</p>
                    <i class="fa fa-exclamation-triangle fa-2x text-warning"></i>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary px-4" id="cancel" data-dismiss="modal">Cancel</button>

                    <button type="button" class="btn btn-danger px-4" id="confirmDeleteBtn">Yes, Delete</button>
                </div>
            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>


    $(document).ready(function () {
        let deleteForm = null;

        // Delete button click
        $('.delete-btn').click(function () {
            deleteForm = $(this).closest('form'); // Store the form
            $('#deleteModal').modal('show'); // Show modal
        });

        // Confirm delete from modal
        $('#confirmDeleteBtn').click(function () {
            if (deleteForm) {
                deleteForm.submit();
            }
        });
    });

</script>




<?php echo $__env->make("admin.layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\School\resources\views/admin/abouts/index.blade.php ENDPATH**/ ?>