<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; {{ now()->year }}  | Developed by <a href="{{url('https://github.com/mdrafiunislam17')}}" target="_blank">rafiun</a></span>
        </div>
    </div>
</footer>
